//
//  SceneDelegate.h
//  方块图
//
//  Created by jcl on 2021/6/4.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

